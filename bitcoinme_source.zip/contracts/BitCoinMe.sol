// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/access/AccessControl.sol";

/**
 * @title BitCoinMe Token
 * @dev Token ERC20 avec supply plafonné et gestion multi-propriétaires
 * 
 * Caractéristiques:
 * - Supply initial: 6,666,666,666 BCM
 * - Supply maximum: 8,888,888,888 BCM
 * - Multi-propriétaires via AccessControl
 * - Transparent: toutes les actions sont traçables via events
 */
contract BitCoinMe is ERC20, AccessControl {
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");
    
    // Supply maximum en unités de base (avec 18 décimales)
    uint256 public constant MAX_SUPPLY = 8_888_888_888 * 10**18;
    
    /**
     * @dev Événement émis lors du mint de nouveaux tokens
     */
    event TokensMinted(address indexed to, uint256 amount, address indexed minter);
    
    /**
     * @dev Événement émis lors de l'ajout d'un propriétaire
     */
    event OwnerAdded(address indexed newOwner, address indexed addedBy);
    
    /**
     * @dev Événement émis lors du retrait d'un propriétaire
     */
    event OwnerRemoved(address indexed owner, address indexed removedBy);

    /**
     * @dev Constructeur du contrat
     * @param initialOwners Liste des adresses qui seront propriétaires initiaux
     * 
     * Le déployeur reçoit:
     * - Le rôle DEFAULT_ADMIN_ROLE (peut gérer tous les rôles)
     * - Le rôle MINTER_ROLE (peut minter des tokens)
     * - L'initial supply de 6,666,666,666 BCM
     */
    constructor(address[] memory initialOwners) ERC20("BitCoinMe!", "BCM") {
        require(initialOwners.length > 0, "Au moins un proprietaire requis");
        
        // Mint l'initial supply au déployeur
        uint256 initialSupply = 6_666_666_666 * 10**18;
        _mint(msg.sender, initialSupply);
        
        // Configurer les rôles pour tous les propriétaires initiaux
        for (uint256 i = 0; i < initialOwners.length; i++) {
            require(initialOwners[i] != address(0), "Adresse proprietaire invalide");
            _grantRole(DEFAULT_ADMIN_ROLE, initialOwners[i]);
            _grantRole(MINTER_ROLE, initialOwners[i]);
            emit OwnerAdded(initialOwners[i], msg.sender);
        }
    }

    /**
     * @dev Mint de nouveaux tokens
     * @param to Adresse qui recevra les tokens
     * @param amount Quantité de tokens à minter (en unités de base)
     * 
     * Restrictions:
     * - Seuls les détenteurs du MINTER_ROLE peuvent appeler
     * - Ne peut pas dépasser MAX_SUPPLY
     */
    function mint(address to, uint256 amount) public onlyRole(MINTER_ROLE) {
        require(to != address(0), "Mint vers adresse zero");
        require(totalSupply() + amount <= MAX_SUPPLY, "Depassement du supply maximum");
        
        _mint(to, amount);
        emit TokensMinted(to, amount, msg.sender);
    }

    /**
     * @dev Ajouter un nouveau propriétaire
     * @param newOwner Adresse du nouveau propriétaire
     * 
     * Le nouveau propriétaire reçoit:
     * - DEFAULT_ADMIN_ROLE (peut gérer d'autres propriétaires)
     * - MINTER_ROLE (peut minter des tokens)
     */
    function addOwner(address newOwner) public onlyRole(DEFAULT_ADMIN_ROLE) {
        require(newOwner != address(0), "Adresse proprietaire invalide");
        
        _grantRole(DEFAULT_ADMIN_ROLE, newOwner);
        _grantRole(MINTER_ROLE, newOwner);
        emit OwnerAdded(newOwner, msg.sender);
    }

    /**
     * @dev Retirer un propriétaire
     * @param owner Adresse du propriétaire à retirer
     * 
     * Retire tous les rôles de l'adresse spécifiée
     */
    function removeOwner(address owner) public onlyRole(DEFAULT_ADMIN_ROLE) {
        require(owner != address(0), "Adresse proprietaire invalide");
        
        _revokeRole(DEFAULT_ADMIN_ROLE, owner);
        _revokeRole(MINTER_ROLE, owner);
        emit OwnerRemoved(owner, msg.sender);
    }

    /**
     * @dev Vérifier si une adresse est propriétaire
     * @param account Adresse à vérifier
     * @return bool true si l'adresse a le rôle DEFAULT_ADMIN_ROLE
     */
    function isOwner(address account) public view returns (bool) {
        return hasRole(DEFAULT_ADMIN_ROLE, account);
    }

    /**
     * @dev Obtenir le supply restant disponible pour le mint
     * @return uint256 Quantité de tokens pouvant encore être mintés
     */
    function remainingMintableSupply() public view returns (uint256) {
        return MAX_SUPPLY - totalSupply();
    }
}